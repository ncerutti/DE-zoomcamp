-- Docs: https://docs.mage.ai/guides/sql-blocks
SELECT * FROM ny_taxi.yellow_cab_data LIMIT 10;